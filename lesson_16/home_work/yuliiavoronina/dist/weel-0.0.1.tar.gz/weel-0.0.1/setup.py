from setuptools import setup, find_packages

setup(
    name='weel',
    version='0.0.1',
    author="Yuliia Voronina",
    packages=find_packages(),
    install_requires=[],
    keywords=['python', 'first package'],
)
